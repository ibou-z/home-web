# Liquid Glass MacBook Dashboard

A premium, futuristic personal dashboard and application launcher inspired by Apple's Liquid Glass design language, iOS 26 lock-screen clock, and macOS Tahoe aesthetic.

Built with React 19, TypeScript, Tailwind CSS, and Vite. Designed to run smoothly at 60 FPS in any modern desktop browser (including 2018 MacBook Air and Windows).

---

## ✨ Features

- **Apple iPhone iOS 26 Liquid Glass Clock**:
  - Floating typography directly over the animated gradient background (no cards, boxes, or panels).
  - Authentic optical glass translucency, subtle micro-bevel edge contours, and natural Fresnel refraction.
  - 100% accurate custom color rendering without unwanted white patches or tint clashing.
  - Triple-mode color controls: Full-Spectrum Picker, Custom HEX input, and Discrete R/G/B (0-255) channel inputs.
  - Fully independent controls for Main Glass, Specular Highlights, Optical Reflections, and Outer Glow/Caustics.
  - Master toggles to enable/disable highlights, reflections, and glow independently.
  - 8 curated Apple presets + quick mandatory test palette.
  - Adjustable font weights, proportions, digit tracking, blur, and animations (12h/24h toggle, seconds toggle).

- **Customisable Animated Ambient Glow**:
  - Multi-stop fluid ambient gradient animation.
  - Ambient presets: *macOS Tahoe Aurora*, *Electric Neon*, *Cyber Velvet*, *Hyper Magenta*, *Deep Midnight*, *Emerald Matrix*, *Solar Flare*.
  - Full custom 4-color gradient designer with adjustable intensity and animation speed.

- **Rearrangeable Application Dock & Launcher**:
  - 10 default high-productivity apps: 7reels, YouTube, Glow RRMumify, Microsoft Teams, Google, Copilot, ChatGPT, Claude, Humanize AI, and more.
  - Drag-and-drop layout rearrangement with live state persistence.
  - Add custom apps (with custom URLs, titles, categories, icons, and accent colors).
  - Edit or remove any app shortcut at any time.

- **macOS Tahoe Top Bar & Spotlight Search**:
  - Interactive status bar with live clock, network/battery indicators, and quick action controls.
  - Spotlight Search overlay triggered via `⌘K` or `/` with instant keyword filtering and arrow navigation.

- **Complete Persistence & Privacy**:
  - Zero server requirements; all settings, custom apps, and preferences persist in browser `localStorage`.
  - One-click factory reset and layout restoration.

---

## 🚀 Getting Started

### Prerequisites

- Node.js (version 18 or higher)
- npm or pnpm or yarn

### Installation

1. Clone this repository or download and extract the ZIP:
   ```bash
   git clone https://github.com/YOUR_USERNAME/liquid-glass-macbook-dashboard.git
   cd liquid-glass-macbook-dashboard
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the local development server:
   ```bash
   npm run dev
   ```
   Open [http://localhost:3000](http://localhost:3000) (or the port shown in your terminal) in your browser.

4. Build for production:
   ```bash
   npm run build
   ```
   The compiled static website will be in the `dist` directory, ready to deploy to GitHub Pages, Vercel, Netlify, Cloudflare Pages, etc.

---

## 🛠️ Tech Stack

- **Framework**: React 19
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Build Tool**: Vite
